# CobbleCoop Reward Datapack Template

This is a ready-to-edit reward datapack for CobbleCoop on Minecraft 1.21.1.
It replaces the five reward pools included with the mod:

```text
data/cobblecoop/loot_table/cobblecoop/rewards/
|-- common/basic.json
|-- uncommon/basic.json
|-- rare/basic.json
|-- epic/basic.json
`-- legendary/basic.json
```

## Install

Place the downloaded ZIP directly inside:

```text
<world>/datapacks/
```

You may also extract it there as one complete folder. In both cases,
`pack.mcmeta` must be at the root of the ZIP or folder.

Run these commands after installing or editing it:

```text
/reload
/datapack list enabled
```

## Edit rewards

Open the `basic.json` belonging to the rarity you want to change.

- `rolls` is how many entries that pool tries to select.
- `name` is the complete registered item ID.
- `weight` is the relative chance of that entry inside the file.
- `quality` changes its effective weight using the Player's Minecraft Luck.
- `set_count` controls the minimum and maximum item amount.

Example entry:

```json
{
  "type": "minecraft:item",
  "name": "minecraft:diamond",
  "weight": 5,
  "quality": 2,
  "functions": [
    {
      "function": "minecraft:set_count",
      "count": {
        "min": 1,
        "max": 3
      }
    }
  ]
}
```

The item must exist on the server. Items from Cobblemon or another mod may be
used, but the mod that owns that item must also be installed.

## Test

Test one table without earning a bag:

```text
/loot give @s loot cobblecoop:cobblecoop/rewards/common/basic
```

Give yourself a bag and test the complete opening process:

```text
/give @s cobblecoop:common_reward_bag
```

Replace `common` with `uncommon`, `rare`, `epic`, or `legendary` when needed.

## Add a pool instead of replacing one

This template replaces the included `basic.json` files because it uses the
same `cobblecoop` namespace and resource paths.

To add another equally likely pool, use a different namespace and file name:

```text
data/myserver/loot_table/cobblecoop/rewards/rare/berries.json
```

CobbleCoop discovers it automatically after `/reload`. If a rarity contains
three JSON files, each file has a one-in-three chance of being selected.
`weight` only compares entries inside one file; it does not change which file
is selected.

## Common mistakes

- Use `loot_table`, singular, for Minecraft 1.21.1.
- Keep namespaces and file names lowercase.
- Use only `common`, `uncommon`, `rare`, `epic`, or `legendary` as tier folders.
- Check commas, brackets, item IDs, and JSON syntax before running `/reload`.
- Reward contents do not need an entry in `rewards.toml`.

For every option and more examples, read the
[complete reward pool guide](../README.md).