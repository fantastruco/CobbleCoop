# CobbleCoop Reward Datapack Template

This Minecraft 1.21.1 datapack replaces the five default CobbleCoop Reward Bag
pools.

## Install

Place this ZIP directly inside `<world>/datapacks/`, then run:

```text
/reload
/datapack list enabled
```

`pack.mcmeta` must remain at the root of the ZIP or extracted folder.

## Edit

Each rarity has one file under:

```text
data/cobblecoop/loot_table/cobblecoop/rewards/<rarity>/basic.json
```

- `rolls` controls how many entries are selected.
- `name` is the complete item ID.
- `weight` compares entries inside that JSON file.
- `quality` optionally reacts to the Player's Minecraft Luck.
- `set_count` controls the item amount.

Any modded item may be used when its owning mod is installed on the server.

## Test

```text
/loot give @s loot cobblecoop:cobblecoop/rewards/common/basic
/give @s cobblecoop:common_reward_bag
```

## Add another pool

To add instead of replace, use another namespace or file name:

```text
data/myserver/loot_table/cobblecoop/rewards/rare/berries.json
```

Several JSON files in one rarity are selected with equal probability. Item
`weight` values apply only after one file has been selected.

Use `loot_table`, singular. Keep namespaces and file names lowercase. Reward
contents do not need an entry in `rewards.toml`.
